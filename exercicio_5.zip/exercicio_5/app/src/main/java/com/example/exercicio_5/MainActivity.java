package com.example.exercicio_5;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setTitle("Exercício 5");
        setContentView(R.layout.constraint_layout);

        EditText nome = findViewById(R.id.nome);
        EditText matricula = findViewById(R.id.matricula);
        EditText notaUm = findViewById(R.id.nota_um);
        EditText notaDois = findViewById(R.id.nota_dois);

        Button calcular = findViewById(R.id.calcular_nota);

        TextView resultado = findViewById(R.id.Resultado);

        calcular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                float nota_um = Float.parseFloat(notaUm.getText().toString());
                float nota_dois = Float.parseFloat(notaDois.getText().toString());
                double notaFinal = (nota_um * 0.4) + (nota_dois * 0.6);

                @SuppressLint("DefaultLocale")
                String conteudo = "A nota final do aluno " + nome.getText().toString() +
                        " é " + String.format("%.2f", notaFinal);

                resultado.setText(conteudo);
            }
        });
    }
}
