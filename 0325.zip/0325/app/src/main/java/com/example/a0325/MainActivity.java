package com.example.a0325;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.annotation.MainThread;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setTitle("0325");
        setContentView(R.layout.main_activity);
    }

    // public - acessível por qualquer classe, seja no mesmo pacote ou não
    // protected - acessível por qualquer classe, desde que esteja no mesmo pacote
    // private - acessível somente dentro da própria classe
    // vazio - acessível por qualquer classe no mesmo pacote

    public void chamaSegundaTela(View view) {
        EditText nome = findViewById(R.id.editTextNome);
        EditText senha = findViewById(R.id.editTextSenha);

        String nomeInformado = nome.getText().toString();
        String senhaInformada = senha.getText().toString();

        Intent meuIntent = new Intent(this, SegundaTela.class);
        meuIntent.putExtra("nomeDoUsuario", nomeInformado);
        meuIntent.putExtra("senhaDoUsuario", senhaInformada);
        startActivity(meuIntent);
    }
}
