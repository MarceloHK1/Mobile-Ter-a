package com.example.a0429_sql;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.textfield.TextInputEditText;

import java.util.ArrayList;


public class MainActivity extends AppCompatActivity {
    private TextInputEditText nome;
    private TextInputEditText telefone;
    private ListView contatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        inicializaTela();
    }

    private void inicializaTela() {
        nome = findViewById(R.id.editTextNome);
        telefone = findViewById(R.id.editTextTelefone);
        Button salvar = findViewById(R.id.buttonSalvar);
        contatos = findViewById(R.id.listViewContatos);

        salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarContato();
            }
        });
    }

    private void salvarContato() {
        String nomeInformado = nome.getText().toString();
        String telefoneInformado = telefone.getText().toString();

        SQLiteDatabase db = openOrCreateDatabase("agenda.db", MODE_PRIVATE, null);
        db.execSQL("CREATE TABLE IF NOT EXISTS tab_contato (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "nome TEXT NOT NULL," +
                "telefone TEXT NOT NULL)");

        db.execSQL("INSERT INTO tab_contato (nome, telefone) VALUES ('"+nomeInformado+"', '"+telefoneInformado+"') ");

        Cursor cursor = db.rawQuery("SELECT * FROM tab_contato", null);
        ArrayList<String> arrayContatos = new ArrayList<>();

        if (cursor.moveToFirst()) {
            do {
                Log.d("SQL", "NOME CADASTRADO: " + cursor.getString(cursor.getColumnIndexOrThrow("nome")) +
                        " TELEFONE CADASTRADO: " + cursor.getString(cursor.getColumnIndexOrThrow("telefone")));

                arrayContatos.add("Nome: " + cursor.getString(cursor.getColumnIndexOrThrow("nome")) +
                        "\nTelefone: " + cursor.getString(cursor.getColumnIndexOrThrow("telefone")));
            } while (cursor.moveToNext());
        }

        Toast.makeText(MainActivity.this, R.string.toast_salvar, Toast.LENGTH_LONG).show();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, androidx.appcompat.R.layout.support_simple_spinner_dropdown_item, arrayContatos);
        contatos.setAdapter(adapter);
    }
}