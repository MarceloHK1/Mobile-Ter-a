package com.example.quatro;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.relative_layout);

        EditText nome = findViewById(R.id.editTextText);
        EditText sobrenome = findViewById(R.id.editTextText2);
        EditText telefone = findViewById(R.id.editTextText3);
        Button salvar = findViewById(R.id.button);
        Button cancelar = findViewById(R.id.button2);

        salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(MainActivity.this,
                        nome.getText().toString() + " " + sobrenome.getText().toString() + " - " + telefone.getText(),
                        Toast.LENGTH_SHORT).show();
            }
        });

        cancelar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nome.setText("");
                sobrenome.setText("");
                telefone.setText("");

                Toast.makeText(MainActivity.this,
                        "Operação cancelada.",
                        Toast.LENGTH_SHORT).show();
            }
        });
    }
}
