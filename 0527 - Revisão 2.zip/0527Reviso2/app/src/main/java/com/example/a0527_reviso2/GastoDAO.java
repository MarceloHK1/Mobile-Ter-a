package com.example.a0527_reviso2;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface GastoDAO {
    @Insert
    void insertGasto(Gasto gasto);

    @Query("SELECT * FROM tab_gastos")
    List<Gasto> selectAll();

    @Query("SELECT * FROM tab_gastos ORDER BY valor DESC LIMIT 1")
    Gasto buscaMaiorGasto();
}
