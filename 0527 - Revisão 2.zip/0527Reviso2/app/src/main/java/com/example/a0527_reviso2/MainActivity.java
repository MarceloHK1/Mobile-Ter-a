package com.example.a0527_reviso2;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.room.Room;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private EditText descricao, valor;
    private Button salvar;
    private TextView resultado, maiorGasto;
    private MyDatabase db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        descricao = findViewById(R.id.editTextDescricao);
        valor = findViewById(R.id.editTextValor);
        salvar = findViewById(R.id.buttonSalvar);
        resultado = findViewById(R.id.textViewResultado);
        maiorGasto = findViewById(R.id.textViewMaiorGasto);

        db = Room.databaseBuilder(getApplicationContext(), MyDatabase.class, "mydatabase.db").build();

        salvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                salvarGasto();
            }
        });
    }

    private void salvarGasto() {
        String descricaoInformada = descricao.getText().toString();
        Float valorInformado = Float.parseFloat(valor.getText().toString());

        Gasto gastoAtual = new Gasto(descricaoInformada, valorInformado);

        new Thread(new Runnable() {
            @Override
            public void run() {
                db.gastoDAO().insertGasto(gastoAtual);

                atualizaBanco();
            }
        }).start();
    }

    private void atualizaBanco() {
        List<Gasto> listaGastos = db.gastoDAO().selectAll();
        Gasto maxGasto = db.gastoDAO().buscaMaiorGasto();

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                StringBuilder builder = new StringBuilder();
                for (Gasto g : listaGastos) {
                    builder.append("Descrição: ").append(g.getDescricao())
                            .append(" | Valor: R$ ").append(g.getValor())
                            .append("\n");
                }
                resultado.setText(builder.toString());

                String builderMaior = "Descrição: " + maxGasto.getDescricao() + " | Valor: R$ " + maxGasto.getValor();
                maiorGasto.setText(builderMaior);
            }
        });
    }
}