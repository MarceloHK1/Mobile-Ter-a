package com.example.primeiraaplicao;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class LayoutActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Conecta o layout
        setContentView(R.layout.mainlayout);

        //Dois
        //Pega o elemento do layout para alterá-lo
        TextView textViewHello = findViewById(R.id.hello);
        TextView textViewUm = findViewById(R.id.titulo);
        TextView textViewDois = findViewById(R.id.leiaute);
        TextView textViewTres = findViewById(R.id.nome);

        //Troca o valor dos elementos do layout
        textViewHello.setText(R.string.hello);
        textViewUm.setText(R.string.titulo);
        textViewDois.setText(R.string.leiaute);
        textViewTres.setText(R.string.nome);

        Button buttonTraduzir = findViewById(R.id.btn_traduzir);
        buttonTraduzir.setText(R.string.btnTraduzir);
        //Pega uma classe anônima que implementa a função 'onClick'
        buttonTraduzir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (textViewHello.getText().equals(getString(R.string.hello))) {
                    textViewHello.setText(R.string.ola);
                } else {
                    textViewHello.setText(R.string.hello);
                }
            }
        });

        //Três
        EditText nome = findViewById(R.id.plainText1);
        EditText senha = findViewById(R.id.editTextPassword);
        Button buttonOK = findViewById(R.id.btnOK);

        buttonOK.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (nome.getText().toString().equals("admin") && senha.getText().toString().equals("admin")) {
                    Toast.makeText(LayoutActivity.this,
                            "Login efetuado com sucesso!",
                            Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(LayoutActivity.this,
                            "Usuário ou senha incorretos.",
                            Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
