package com.example.trabalhofinal;


import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

@Entity(
        tableName = "tab_produtos",
        foreignKeys = @ForeignKey(
                entity = Usuario.class,
                parentColumns = "id",
                childColumns = "usuario_id"
        )
)
public class Produto {
    @PrimaryKey(autoGenerate = true)
    private int id_produto;

    @ColumnInfo(name = "nome")
    private String nome_produto;

    @ColumnInfo(name = "preco")
    private Float preco_produto;

    @ColumnInfo(name = "usuario_id")
    private int usuario_id;

    public Produto(String nome, Float preco, int usuarioID) {
        this.nome_produto = nome;
        this.preco_produto = preco;
        this.usuario_id = usuarioID;
    }

    public int getId_produto() {
        return id_produto;
    }

    public void setId_produto(int id_produto) {
        this.id_produto = id_produto;
    }

    public String getNome_produto() {
        return nome_produto;
    }

    public void setNome_produto(String nome_produto) {
        this.nome_produto = nome_produto;
    }

    public Float getPreco_produto() {
        return preco_produto;
    }

    public void setPreco_produto(Float preco_produto) {
        this.preco_produto = preco_produto;
    }

    public int getUsuario_id() {
        return usuario_id;
    }

    public void setUsuario_id(int usuario_id) {
        this.usuario_id = usuario_id;
    }
}
