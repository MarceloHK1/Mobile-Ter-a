package com.example.trabalhofinal;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ProdutoDAO {
    @Insert
    void insertProduto (Produto produto);

    @Query("SELECT * FROM tab_produtos")
    List<Produto> selectAll();

    @Delete
    void deleteProduto (Produto produto);
}
