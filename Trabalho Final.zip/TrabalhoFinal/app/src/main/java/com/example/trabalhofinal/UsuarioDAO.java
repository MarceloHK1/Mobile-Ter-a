package com.example.trabalhofinal;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;

@Dao
public interface UsuarioDAO {
    @Insert
    void insertUsuario (Usuario usuario);

    @Delete
    void deleteUsuario (Usuario usuario);
}
