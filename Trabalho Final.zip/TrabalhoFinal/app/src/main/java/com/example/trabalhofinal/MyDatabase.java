package com.example.trabalhofinal;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {Usuario.class, Produto.class}, version = 1)
public abstract class MyDatabase extends RoomDatabase {
    public abstract UsuarioDAO usuarioDAO();
    public abstract ProdutoDAO produtoDAO();
}
