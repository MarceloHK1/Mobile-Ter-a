package com.example.a0506_roomdb;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ContatoDAO {
    @Insert
    void insertContato (Contato contato);

    @Query("SELECT * FROM tab_contatos")
    List<Contato> selectAll();
}
