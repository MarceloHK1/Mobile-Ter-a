package com.example.a0506_roomdb;

// Data Access Object
import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import java.util.List;

@Dao
public interface ContatoDAO {
// Interface para implementar comandos SQL

    @Insert
    void insertContato (Contato contato);

    @Query("SELECT * FROM tab_contatos")
    List<Contato> selectAll();

    @Delete
    void deleteAll(List<Contato> contatos);
}
