package com.example.a0506_roomdb;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.room.Room;

import java.util.List;

public class MainActivity extends AppCompatActivity {
    private EditText nome;
    private EditText telefone;
    private Button cadastrar;
    private ListView agenda;
    private MyDatabase db;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        nome = findViewById(R.id.editTextNome);
        telefone = findViewById(R.id.editTextTelefone);
        cadastrar = findViewById(R.id.buttonCadastrar);
        agenda = findViewById(R.id.listViewAgenda);

        db = Room.databaseBuilder(getApplicationContext(), MyDatabase.class, "mydatabase.db").build();

        cadastrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                cadastrarUsuario();
            }
        });
    }

    private void cadastrarUsuario() {
        String nomeInformado = nome.getText().toString();
        String telefoneInformado = telefone.getText().toString();
        Contato contatoAtual = new Contato(nomeInformado, telefoneInformado, 0);

        new Thread(new Runnable() {
            @Override
            public void run() {
                db.contatoDAO().insertContato(contatoAtual);

                atualizaAgenda();
            }
        }).start();
    }

    private void atualizaAgenda() {
        List<Contato> listaContatos = db.contatoDAO().selectAll();

        //db.contatoDAO().deleteAll(listaContatos);

        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ArrayAdapter<Contato> adaptador = new ArrayAdapter<>(MainActivity.this, com.google.android.material.R.layout.support_simple_spinner_dropdown_item, listaContatos);
                agenda.setAdapter(adaptador);
            }
        });
    }
}