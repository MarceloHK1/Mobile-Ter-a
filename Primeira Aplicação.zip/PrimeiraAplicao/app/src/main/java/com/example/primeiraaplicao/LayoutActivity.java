package com.example.primeiraaplicao;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.Nullable;

public class LayoutActivity extends Activity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Conecta o layout
        setContentView(R.layout.mainlayout);

        //Pega o elemento do layout para alterá-lo
        TextView textViewHello = findViewById(R.id.hello);
        TextView textViewUm = findViewById(R.id.titulo);
        TextView textViewDois = findViewById(R.id.leiaute);
        TextView textViewTres = findViewById(R.id.nome);

        //Troca o valor dos elementos do layout
        textViewHello.setText(R.string.hello);
        textViewUm.setText(R.string.titulo);
        textViewDois.setText(R.string.leiaute);
        textViewTres.setText(R.string.nome);

        Button buttonTraduzir = findViewById(R.id.btn_traduzir);
        buttonTraduzir.setText(R.string.btnTraduzir);
        //Pega uma classe anônima que implementa a função 'onClick'
        buttonTraduzir.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (textViewHello.getText().equals(getString(R.string.hello))) {
                    textViewHello.setText(R.string.ola);
                } else {
                    textViewHello.setText(R.string.hello);
                }
            }
        });
    }
}
