package com.example.exerccio6;

import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class SegundaTela extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_segunda_tela);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        inicializaSegundaTela();
    }

    private void inicializaSegundaTela() {
        TextView resultado = findViewById(R.id.textView);

        String nomeRecebido = getIntent().getStringExtra("nomeDoAluno");
        String matriculaRecebida = getIntent().getStringExtra("matriculaDoAluno");
        double notaRecebida = getIntent().getDoubleExtra("resultado", 0.0);

        String conteudo = "Bem vindo aluno " + nomeRecebido +
                "!\n\nMatrícula " + matriculaRecebida +
                ".\nSua nota final é: " + notaRecebida + ".";

        resultado.setText(conteudo);
    }
}