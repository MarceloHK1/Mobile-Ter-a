package com.example.a0520_contador;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private TextView contadorPassos, distancia;
    private SensorManager sensorManager;
    private Sensor acelerometro;
    private SensorEventListener listener;
    private ProgressBar barraDeProgresso;
    private int contador;
    private double distanciaPercorrida;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        inicializaContador();

    }

    @Override
    protected void onResume() {
        super.onResume();
        sensorManager.registerListener(listener, acelerometro, SensorManager.SENSOR_DELAY_NORMAL);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sensorManager.unregisterListener(listener);
    }

    private void inicializaContador() {
        contadorPassos = findViewById(R.id.textViewContador);
        distancia = findViewById(R.id.textViewDistancia);
        barraDeProgresso = findViewById(R.id.progressBarQtdPassos);
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);

        acelerometro = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        contador = 0;

        listener = new SensorEventListener() {
            @Override
            public void onSensorChanged(SensorEvent event) {
                float x = event.values[0];
                float y = event.values[1];
                float z = event.values[2];

                double magnitude = Math.sqrt(x*x + y*y + z*z);

                if (magnitude > 12) {
                    contador++;
                    distanciaPercorrida = contador * 0.76;
                    contadorPassos.setText("A quantidade de passos atual é: " + contador);
                    distancia.setText("A distância percorrida foi: " + distanciaPercorrida);
                    barraDeProgresso.setProgress(contador);
                }
            }

            @Override
            public void onAccuracyChanged(Sensor sensor, int accuracy) {

            }
        };
    }
}